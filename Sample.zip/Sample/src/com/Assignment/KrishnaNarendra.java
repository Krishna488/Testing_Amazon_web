package com.Assignment;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.TakesScreenshot;
import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.io.Files;

import org.openqa.selenium.OutputType;
import java.io.File;
import javax.imageio.ImageIO;
import java.io.IOException;
public class KrishnaNarendra {

	public static void main(String[] args) throws InterruptedException, IOException {
	    System.setProperty("webdriver.chrome.driver", "C:\\Driver\\chromedriver.exe");
	    WebDriver driver = new ChromeDriver();
	    
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    driver.get("https://www.amazon.com/");
	   Thread.sleep(4000);
	   driver.manage().window().maximize();
	   driver.findElement(By.id("nav-global-location-popover-link")).click();
	   Thread.sleep(5000);
	   WebElement zipcode = driver.findElement(By.id("GLUXZipUpdateInput"));
	   zipcode.sendKeys("64468");
	   Thread.sleep(15000);
	   WebElement elementtohover = driver.findElement(By.xpath("//span[@id='nav-link-accountList-nav-line-1']"));
	   Actions action = new Actions(driver);
	   action.moveToElement(elementtohover).perform();
	   Thread.sleep(2000);
	   WebElement signup = driver.findElement(By.xpath("//span[@class='nav-action-inner']"));
	   action.moveToElement(signup).click().perform();
	   Thread.sleep(2000);
	   WebElement Email = driver.findElement(By.id("ap_email"));
	   Email.sendKeys("krishnanarendra.s2v@gmail.com");
	   WebElement continueclick = driver.findElement(By.id("continue"));
	   continueclick.click();
	   Thread.sleep(4000);
	   WebElement password = driver.findElement(By.id("ap_password"));
	   password.sendKeys("Pothunar#488");
	   WebElement Signin = driver.findElement(By.id("signInSubmit"));
	   Signin.click();
	   Thread.sleep(15000);
	   WebElement searchBox = driver.findElement(By.id("twotabsearchtextbox"));
	    searchBox.sendKeys("Laptop");
	    searchBox.submit();
	    
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".s-main-slot")));

	    List<WebElement> products=driver.findElements(By.cssSelector(".s-main-slot .s-result-item"));
	    if(products.size()>0) {
	    	products.get(0).findElement(By.xpath("//div[@class='s-widget-container s-spacing-small s-widget-container-height-small celwidget slot=MAIN template=SEARCH_RESULTS widgetId=search-results_1']//h2[@class='a-size-mini a-spacing-none a-color-base s-line-clamp-2']//span[1]")).click();
	    }
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("imgTagWrapperId")));
	    
	    String productPrice = driver.findElement(By.xpath(".//*[@id='dealBadgeSupportingText']//following::span[@class='a-price-whole'][1]")).getText();
	    
	    driver.findElement(By.id("add-to-cart-button")).click();
	    Thread.sleep(10000);
	    WebElement cartPriceElement = driver.findElement(By.xpath(".//*[@id='sw-subtotal-item-count']//following::span[@class='a-price-whole'][1]"));
        String cartPrice = cartPriceElement.getText();
	    
        if (productPrice.equals(cartPrice)) {
            System.out.println("The correct price is displayed in the cart: " + cartPrice);
        } else {
            System.out.println("The price in the cart is incorrect. Expected: " + productPrice + ", but got: " + cartPrice);
        }
        
        driver.findElement(By.id("nav-cart")).click();
        Thread.sleep(5000);
        File f=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        Files.copy(f, new File("C:\\Screenshot\\productscreenshot.png"));
        
        
       //Adjust quantity of product in cart
        WebElement quantityDropdown= driver.findElement(By.id("a-autoid-1-announce"));
        quantityDropdown.click();
        Thread.sleep(4000);
        WebElement Quantity = driver.findElement(By.id("quantity_2"));
        Quantity.click();
        Thread.sleep(4000);
        File g=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        Files.copy(g, new File("C:\\Screenshot\\productQuantity.png"));
        Thread.sleep(2000);
       //decrease product quantity
        WebElement QuantityDropdown= driver.findElement(By.xpath(".//*[@class='a-button-text a-declarative']"));
        QuantityDropdown.click();
        Thread.sleep(20000);
       // WebElement decrease = driver.findElement(By.xpath("//div[@id='a-popover-3']//a[@id='quantity_1']"));
       // decrease.click();
        //Thread.sleep(4000);
        File h=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        Files.copy(h, new File("C:\\Screenshot\\productdecreaseQuantity.png"));
        Thread.sleep(4000);
        
      //coupon code
        WebElement checkout = driver.findElement(By.xpath("//input[@name='proceedToRetailCheckout']"));
        checkout.click();
        Thread.sleep(4000);
        WebElement address = driver.findElement(By.xpath("//input[@data-testid='Address_selectShipToThisAddress']"));
        address.click();
        Thread.sleep(4000);
        JavascriptExecutor js = (JavascriptExecutor) driver;

        // Scroll down by 1000 pixels
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(10000);
        //WebElement coupon = driver.findElement(By.id("pp-h4ndXD-122"));
        //coupon.sendKeys("hggguyguyfutjvjh");
        //Thread.sleep(4000);
        //WebElement apply = driver.findElement(By.xpath("//input[@name='ppw-claimCodeApplyPressed']"));
        //apply.click();
        Thread.sleep(10000);
        File j=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        Files.copy(j, new File("C:\\Screenshot\\couponcode.png"));
   
        Thread.sleep(4000);
        driver.navigate().back();
        Thread.sleep(4000);
        driver.navigate().back();
        Thread.sleep(4000);
        //Remove Product
        WebElement delete = driver.findElement(By.xpath(".//span[text()='Qty:']//following::input[2]"));
        delete.click();
        Thread.sleep(4000);
        File i=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        Files.copy(i, new File("C:\\Screenshot\\Emptycart.png"));
       
        driver.quit();
	}
	


   
}

